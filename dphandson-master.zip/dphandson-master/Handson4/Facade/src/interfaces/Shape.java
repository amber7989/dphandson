package interfaces;

public interface Shape {
	public void draw();

}
