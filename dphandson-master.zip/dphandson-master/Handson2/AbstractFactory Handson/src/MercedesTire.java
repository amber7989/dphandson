
public class MercedesTire  extends Tire{

}
